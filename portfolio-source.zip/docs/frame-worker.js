// Fetch and decode outside the UI thread. Only the latest neighbourhood is queued.
const compressed = new Map();
const failed = new Set();
let resident = new Set(), priorities = [], active = 0, paused = false;
const inFlight = new Set();
const MAX_BLOBS = 110;
function pump() {
  if (paused) return;
  for (const item of priorities) {
    if (active >= 2) break;
    const key = `${item.width}:${item.frame}`;
    if (resident.has(key) || inFlight.has(key) || failed.has(key)) continue;
    inFlight.add(key); active++;
    load(item, key).finally(() => { active--; inFlight.delete(key); pump(); });
  }
}
async function load(item, key) {
  try {
    let blob = compressed.get(key);
    if (!blob) {
      const name = String(item.frame).padStart(3, '0');
      let response = await fetch(`assets/frames-${item.width}/ezgif-frame-${name}.webp`);
      // Keep the original complete sequence as a compatibility/network fallback.
      if (!response.ok) response = await fetch(`assets/frames/ezgif-frame-${name}.jpg`);
      if (!response.ok) throw new Error('Frame unavailable');
      blob = await response.blob(); compressed.set(key, blob);
      if (compressed.size > MAX_BLOBS) compressed.delete(compressed.keys().next().value);
    }
    if (paused || !priorities.some(p => `${p.width}:${p.frame}` === key)) return;
    const bitmap = await createImageBitmap(blob);
    if (paused || !priorities.some(p => `${p.width}:${p.frame}` === key)) { bitmap.close(); return; }
    resident.add(key);
    postMessage({ key, frame: item.frame, width: item.width, bitmap }, [bitmap]);
  } catch { failed.add(key); postMessage({ error: key }); }
}
self.onmessage = ({ data }) => {
  paused = data.paused;
  resident = new Set(data.resident || []);
  priorities = data.priorities || [];
  pump();
};
