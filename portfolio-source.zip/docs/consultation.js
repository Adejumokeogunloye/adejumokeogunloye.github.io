const form = document.querySelector('#consultation-form');
const status = document.querySelector('#consultation-status');
const confirmation = document.querySelector('#consultation-confirmation');
confirmation.querySelector('button').addEventListener('click', () => confirmation.close());
// Set this only after the submission service and destination Sheet are connected.
const endpoint = form.dataset.endpoint || '';
let pendingRequest = null;
form.addEventListener('submit', async event => {
  event.preventDefault();
  const name = form.elements.name.value.trim();
  const email = form.elements.email.value.trim();
  const project = form.elements.project.value.trim();
  for (const [field, value] of [[form.elements.name, name], [form.elements.project, project]]) {
    field.setCustomValidity(value ? '' : 'Please complete this field.');
  }
  if (!form.reportValidity()) return;
  if (!endpoint) {
    status.textContent = 'Online consultation requests are not available yet. Please use the WhatsApp link to get in touch.';
    return;
  }
  const button = form.querySelector('button[type="submit"]');
  const payload = JSON.stringify({name, email, project});
  if (!pendingRequest || pendingRequest.payload !== payload) {
    pendingRequest = { payload, requestId: crypto.randomUUID() };
  }
  button.disabled = true;
  button.textContent = 'Sending your request…';
  status.textContent = '';
  try {
    const response = await fetch(endpoint, {
      method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      credentials: 'omit', redirect: 'follow',
      body: JSON.stringify({ name, email, project, requestId: pendingRequest.requestId, website: form.elements.website.value }),
      signal: AbortSignal.timeout(30000)
    });
    if (!response.ok) throw new Error('Request failed');
    const result = await response.json();
    if (result.ok !== true || result.requestId !== pendingRequest.requestId) throw new Error('Save not confirmed');
    form.reset();
    pendingRequest = null;
    status.textContent = 'Your consultation request has been received. I’ll contact you by email to discuss your project and agree a time.';
    confirmation.showModal();
  } catch {
    status.textContent = 'Your request could not be confirmed. Your details are still here. Please try again or contact me on WhatsApp.';
  } finally {
    button.disabled = false;
    button.textContent = 'Book a free consultation';
  }
});
form.addEventListener('input', event => { if (event.target.setCustomValidity) event.target.setCustomValidity(''); });
