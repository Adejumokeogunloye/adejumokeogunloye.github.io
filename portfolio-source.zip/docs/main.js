import * as THREE from './vendor/three/three.module.js';
import { createPortrait } from './portrait.js';
import { createButterfly } from './butterfly.js';

const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
createButterfly({ reduced });
const $ = s => document.querySelector(s);
const menu = $('.menu-toggle');
menu.addEventListener('click', () => { const open = menu.getAttribute('aria-expanded') !== 'true'; menu.setAttribute('aria-expanded', String(open)); $('#navigation').classList.toggle('open', open); });
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => { menu.setAttribute('aria-expanded', 'false'); $('#navigation').classList.remove('open'); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') { menu.setAttribute('aria-expanded', 'false'); $('#navigation').classList.remove('open'); } });
$('#year').textContent = new Date().getFullYear();

const brandDialog = $('#brand-dialog');
document.querySelectorAll('.brand-card a').forEach(link => {
  link.setAttribute('aria-haspopup', 'dialog');
  link.removeAttribute('target');
  const card = link.closest('.brand-card');
  const title = card.querySelector('h3').textContent;
  link.setAttribute('aria-label', `View ${title} website screenshot`);
  link.addEventListener('click', event => {
    event.preventDefault();
    const source = card.querySelector('img');
    $('#brand-dialog-title').textContent = title;
    $('#brand-dialog-image').src = source.src;
    $('#brand-dialog-image').alt = source.alt;
    brandDialog.showModal();
  });
});
$('.close-brand').addEventListener('click', () => brandDialog.close());
brandDialog.addEventListener('click', event => {
  if (event.target !== brandDialog) return;
  const bounds = brandDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) brandDialog.close();
});

// Restored original frames with the original gaze and scroll mappings.
const portraitPlayer = createPortrait({ canvas: $('#portrait'), hero: $('.hero'), fallback: $('.portrait-fallback'), reduced });

function setupMotion() {
  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);
  const about = $('.about-copy');
  about.innerHTML = [about.textContent.trim()].map(text => { const line = document.createElement('span'); line.className = 'line'; const inner = document.createElement('span'); inner.textContent = text; line.append(inner); return line.outerHTML; }).join(' ');
  if (!reduced) {
    gsap.from('.about-copy .line > span', { yPercent: 110, duration: .8, stagger: .13, scrollTrigger: { trigger: '.about-copy', start: 'top 90%', once: true } });
    gsap.from('.hero-title .eyebrow, .hero-title h1, .hero-bottom', { y: 28, opacity: 0, duration: 1, stagger: .15, ease: 'power3.out' });
    document.querySelectorAll('.reveal').forEach(el => gsap.from(el, { yPercent: 15, opacity: 0, duration: .85, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 92%', once: true } }));
    ScrollTrigger.create({ trigger: '.hero', start: 'top top', end: 'bottom top', onUpdate: self => { portraitPlayer.setProgress(self.progress); } });
  }
}

if (window.gsap && window.ScrollTrigger) setupMotion();
else window.addEventListener('DOMContentLoaded', setupMotion, { once: true });

const projectData = [
  ['UI/UX Case Study', 'INTERFACE / DESIGN SYSTEM', 'An interactive interface study exploring layout, hierarchy, and a light/dark appearance control.', '<div class="mini-browser"><div class="browser-dots">•••</div><div class="mini-title">A clearer way<br>to get there.</div><div class="mini-layout"><div class="mini-block"></div><div class="mini-lines"></div></div></div>'],
  ['3D Interactive Experience', 'THREE.JS / WEBGL', 'A material and lighting exploration. Move across the preview to rotate its real WebGL geometry.', '<div class="orb"></div>'],
  ['Mobile Dashboard', 'UI DESIGN / DATA', 'A compact dashboard concept. Switch between time ranges to explore the sample data.', '<div class="mini-phone"><small>OVERVIEW</small><div class="phone-balance">₦24,800</div><div class="bars"><i></i><i></i><i></i><i></i><i></i></div><div class="mini-lines"></div></div>'],
  ['Studio Index', 'BRAND / WEB DESIGN', 'A typographic studio concept. Filter its collection by discipline.', '<div class="poster">less, but<br>better.</div>'],
  ['Developer Playground', 'JAVASCRIPT / INTERACTION', 'A small interactive color tool. Choose a color and copy the value for your own ideas.', '<div class="mini-code">const idea = {<br>&nbsp; curiosity: true,<br>&nbsp; possibilities: Infinity<br>};<br>build(idea);</div>'],
  ['Type in Motion', 'TYPOGRAPHY / MOTION', 'An adjustable typography study. Change the spacing and see the composition respond.', '<div class="type-art">Aa.</div>']
];
$('#projects').innerHTML = projectData.map((p, i) => `<article class="project-card"><button class="project-open" data-project="${i}" aria-label="Open ${p[0]} interactive demo"><div class="project-art art-${i + 1}">${p[3]}</div><div class="project-caption"><div><h3><span class="project-number">0${i + 1}</span>${p[0]}</h3><small>${p[1]} · LIVE CONCEPT DEMO</small></div><b>↗</b></div></button></article>`).join('');
document.querySelectorAll('.project-open').forEach(button => {
  const art = button.querySelector('.project-art');
  button.addEventListener('pointermove', e => { if (reduced || e.pointerType === 'touch') return; const r = art.getBoundingClientRect(); art.style.transform = `rotateX(${-(e.clientY - r.top - r.height / 2) / 40}deg) rotateY(${(e.clientX - r.left - r.width / 2) / 45}deg)`; });
  button.addEventListener('pointerleave', () => { art.style.transform = ''; });
  button.addEventListener('click', () => openProject(Number(button.dataset.project)));
});
const dialog = $('#project-dialog'); let demoCleanup = () => {};
$('.close-dialog').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', e => { if (e.target === dialog) { const r = dialog.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close(); } });
dialog.addEventListener('close', () => { demoCleanup(); demoCleanup = () => {}; });
$('#dialog-contact').addEventListener('click', () => dialog.close());
function openProject(i) {
  demoCleanup(); $('#dialog-title').textContent = projectData[i][0]; $('#dialog-type').textContent = `0${i + 1} / INTERACTIVE CONCEPT DEMO`; $('#dialog-description').textContent = projectData[i][2];
  const stage = $('#demo-stage'); stage.style.background = ''; stage.style.color = ''; dialog.showModal();
  if (i === 0) { stage.innerHTML = '<div class="demo-panel"><p class="eyebrow">A CLEARER WAY</p><h3>Your next idea starts here.</h3><p>One interface. Two ways to see it.</p><button>Switch appearance</button></div>'; stage.querySelector('button').onclick = () => { const dark = stage.dataset.dark !== 'true'; stage.dataset.dark = String(dark); stage.style.background = dark ? '#12161f' : '#eae3d9'; stage.style.color = dark ? '#f7f4ef' : '#1a1a1a'; }; }
  if (i === 1) { stage.innerHTML = '<canvas aria-label="Interactive three dimensional torus knot" style="width:100%;height:250px"></canvas>'; try { demoCleanup = createDemo3D(stage.querySelector('canvas')); } catch { stage.innerHTML = '<p>WebGL is unavailable in this browser.</p>'; } }
  if (i === 2) { stage.innerHTML = '<div class="demo-panel"><p>SAMPLE ACTIVITY</p><h3 id="demo-value">₦24,800</h3><div class="demo-bar" style="width:60%"></div><div class="demo-tabs"><button>Week</button><button>Month</button><button>Year</button></div></div>'; stage.querySelectorAll('button').forEach((b, n) => b.onclick = () => { $('#demo-value').textContent = ['₦24,800', '₦98,600', '₦1,204,000'][n]; stage.querySelector('.demo-bar').style.width = [35, 65, 100][n] + '%'; }); }
  if (i === 3) { stage.innerHTML = '<div class="demo-panel"><div class="demo-tabs"><button>All</button><button>Design</button><button>Code</button></div><p id="collection">Identity study · Layout system · Web experiment</p></div>'; stage.querySelectorAll('button').forEach((b, n) => b.onclick = () => $('#collection').textContent = ['Identity study · Layout system · Web experiment', 'Identity study · Layout system', 'Web experiment'][n]); }
  if (i === 4) { stage.innerHTML = '<div class="demo-panel"><label for="color-picker">PICK YOUR PALETTE</label><input id="color-picker" type="color" value="#d4a373"><p id="color-value">#d4a373</p><button>Copy color</button><p id="copy-status" role="status"></p></div>'; $('#color-picker').oninput = e => { stage.style.background = e.target.value; $('#color-value').textContent = e.target.value; }; stage.querySelector('button').onclick = async () => { try { await navigator.clipboard.writeText($('#color-picker').value); $('#copy-status').textContent = 'Copied.'; } catch { $('#copy-status').textContent = 'Select the color value above to copy it.'; } }; }
  if (i === 5) { stage.innerHTML = '<div class="demo-panel"><div class="demo-letters">Make it move.</div><label for="spacing">LETTER SPACING</label><input id="spacing" type="range" min="-5" max="10" value="-4"></div>'; $('#spacing').oninput = e => stage.querySelector('.demo-letters').style.letterSpacing = `${e.target.value}px`; }
}
function createDemo3D(canvas) {
  canvas.dataset.engine = `Three.js ${THREE.REVISION}`;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true }); renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); renderer.setSize(canvas.clientWidth, 250, false);
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(40, canvas.clientWidth / 250, .1, 100); camera.position.z = 5;
  const geometry = new THREE.TorusKnotGeometry(.85, .27, 100, 16), material = new THREE.MeshStandardMaterial({ color: 0xd4a373, roughness: .23, metalness: .55 }), mesh = new THREE.Mesh(geometry, material); scene.add(mesh); scene.add(new THREE.HemisphereLight(0xffffff, 0x4e394e, 3)); const light = new THREE.DirectionalLight(0xffe6c4, 4); light.position.set(2, 3, 4); scene.add(light);
  canvas.onpointermove = e => { const r = canvas.getBoundingClientRect(); mesh.rotation.y = (e.clientX - r.left) / r.width * Math.PI * 2; mesh.rotation.x = (e.clientY - r.top) / r.height; };
  let active = true, frame; function loop() { if (!active) return; if (!reduced) mesh.rotation.y += .006; renderer.render(scene, camera); frame = requestAnimationFrame(loop); } loop();
  return () => { active = false; cancelAnimationFrame(frame); geometry.dispose(); material.dispose(); renderer.dispose(); };
}

// Real 3D spheres, with DOM labels projected through the same camera.
try {
  const canvas = $('#bubbles'), labels = [...document.querySelectorAll('.stack-labels span')];
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true }); renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(42, 1, .1, 100); camera.position.z = 12;
  scene.add(new THREE.HemisphereLight(0xfff1db, 0x181e37, 2.8)); const key = new THREE.PointLight(0xffdfb0, 90); key.position.set(-3, 5, 6); scene.add(key);
  const group = new THREE.Group(); scene.add(group); const colors = [0xd4a373, 0xe8c5c8, 0x887e9e, 0xb99e80, 0x717f8d, 0xc99579, 0x7b756e];
  const balls = labels.map((label, i) => { const sphere = new THREE.Mesh(new THREE.SphereGeometry(.65 + i % 3 * .12, 32, 24), new THREE.MeshStandardMaterial({ color: colors[i], roughness: .25, metalness: .32 })); group.add(sphere); return sphere; });
  let visible = false, pointerX = 0, pointerY = 0, width = 1, height = 1, time = 0;
  new ResizeObserver(entries => { const r = entries[0].contentRect; if (Math.abs(r.width - width) < .5 && Math.abs(r.height - height) < .5) return; width = r.width; height = r.height; renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix(); }).observe($('.stack-stage'));
  new IntersectionObserver(e => { visible = e[0].isIntersecting; }).observe(canvas);
  $('.stack-stage').addEventListener('pointermove', e => { if (reduced) return; const r = canvas.getBoundingClientRect(); pointerX = (e.clientX - r.left) / r.width - .5; pointerY = (e.clientY - r.top) / r.height - .5; });
  const vector = new THREE.Vector3(); let previous = performance.now();
  function animate(now) {
    requestAnimationFrame(animate); const dt = Math.min((now - previous) / 1000, .05); previous = now;
    if (!visible || document.hidden) return;
    if (!reduced) time += dt;
    const spread = camera.aspect < 1.5 ? 1.9 : 2.9;
    group.rotation.y += (pointerX * .15 - group.rotation.y) * .04; group.rotation.x += (pointerY * .12 - group.rotation.x) * .04;
    balls.forEach((ball, i) => { ball.position.set(((i % 4) - 1.5) * spread + (i > 3 ? spread * .5 : 0), (i < 4 ? .8 : -1.3) + Math.sin(time * .6 + i * 2) * .22, Math.sin(i) * .5); ball.rotation.y = time * .1; });
    scene.updateMatrixWorld(); balls.forEach((ball, i) => { ball.getWorldPosition(vector); vector.project(camera); labels[i].style.transform = `translate3d(${(vector.x * .5 + .5) * width}px,${(-vector.y * .5 + .5) * height}px,0) translate(-50%,-50%)`; }); renderer.render(scene, camera);
  }
  // Prepare programs and the real render target before the visitor scrolls here.
  const initialBounds = canvas.getBoundingClientRect();
  width = initialBounds.width; height = initialBounds.height;
  renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix();
  const initialSpread = camera.aspect < 1.5 ? 1.9 : 2.9;
  balls.forEach((ball, i) => ball.position.set(((i % 4) - 1.5) * initialSpread + (i > 3 ? initialSpread * .5 : 0), (i < 4 ? .8 : -1.3) + Math.sin(i * 2) * .22, Math.sin(i) * .5));
  renderer.compile(scene, camera); renderer.render(scene, camera);
  requestAnimationFrame(animate);
  canvas.dataset.engine = `Three.js ${THREE.REVISION}`;
} catch { $('.stack-labels').style.cssText = 'position:static;display:flex;flex-wrap:wrap;justify-content:center;gap:20px;padding:70px 10px'; document.querySelectorAll('.stack-labels span').forEach(el => el.style.cssText = 'position:static;transform:none'); }


const sharedProjects = [
 {title:'Pharmacheck',status:'PROTOTYPE / COLLABORATIVE PROJECT',image:'assets/projects/pharmacheck.webp',alt:'Pharmacheck medicine-information concept',description:'An Eleos Hub prototype exploring medicine information and verification, formerly MedVerify. This is collaborative prototype work; its preview does not establish clinical accuracy or medicine authenticity.',url:'https://pharmshield.site.je/public/index.php'},
 {title:'Transit Express',status:'WAITLIST STAGE / COLLABORATIVE PROJECT',image:'assets/projects/transit-express.jpg',alt:'Transit Express student transport concept',description:'A student transport booking concept at the waitlist stage. The preview presents the idea and proposed booking experience.',url:''},
 {title:'SupaTrack',status:'ACADEMIC TEAM PROJECT',image:'assets/projects/supatrack.webp',alt:'SupaTrack supermarket and inventory dashboard',description:'An academic team project focused on supermarket and inventory management, including sales, transactions and stock summaries.',url:''}
];
const sharedDialog=document.querySelector('#shared-dialog');
document.querySelectorAll('[data-shared]').forEach(button=>button.addEventListener('click',()=>{const project=sharedProjects[Number(button.dataset.shared)];document.querySelector('#shared-dialog-title').textContent=project.title;document.querySelector('#shared-dialog-status').textContent=project.status;const image=document.querySelector('#shared-dialog-image');image.src=project.image;image.alt=project.alt;document.querySelector('#shared-dialog-description').textContent=project.description;const live=document.querySelector('#shared-dialog-live');live.hidden=!project.url;if(project.url)live.href=project.url;else live.removeAttribute('href');sharedDialog.showModal();}));
document.querySelector('.close-shared').addEventListener('click',()=>sharedDialog.close());
sharedDialog.addEventListener('click',event=>{if(event.target!==sharedDialog)return;const r=sharedDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)sharedDialog.close();});
