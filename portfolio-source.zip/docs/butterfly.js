// Section-aware flight inspired by the reference bee: hero scale, small traveller, open-lane sweep.
export function createButterfly({ reduced }) {
  const flight=document.querySelector('.butterfly-flight');
  if(!flight)return;
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const mix=(a,b,t)=>a+(b-a)*t;
  const ease=t=>t*t*(3-2*t);
  let width=innerWidth,height=innerHeight,distance=1,frame=0,heroSize=150,smallSize=40,sections=[],lane=null,hero=null;
  function rect(element){if(!element)return null;const r=element.getBoundingClientRect();return{top:r.top+scrollY,height:r.height,left:r.left,right:r.right,width:r.width};}
  function measure(){
    width=innerWidth;height=innerHeight;distance=Math.max(1,document.documentElement.scrollHeight-height);
    const mobile=width<=700;heroSize=mobile?100:width<=1024?132:156;smallSize=mobile?30:clamp(width*.027,30,40);
    flight.style.width=heroSize+'px';flight.style.height=(heroSize*2/3)+'px';
    hero=rect(document.querySelector('.hero'));
    sections=[...document.querySelectorAll('main>section')].map(e=>({id:e.id,...rect(e)}));
    lane=rect(document.querySelector('.butterfly-flight-lane'));
    schedule();
  }
  function pose(section){
    const top=section.top-scrollY;
    const edge=width-smallSize/2-12;
    if(section.id==='home')return{x:Math.min(width*.84,width-heroSize/2-14),y:clamp((width<=700?hero.height*.5:hero.height*.38)-scrollY,height*.17,height*.72),size:heroSize,roll:-8};
    if(section.id==='about')return{x:edge,y:clamp(top+120,height*.24,height*.72),size:smallSize,roll:6};
    if(section.id==='services'&&lane){
      const center=lane.top+lane.height/2-scrollY;
      const visible=ease(clamp(Math.min(center-70,height-70-center)/100,0,1));
      const sweep=ease(clamp((scrollY-(lane.top-height*.72))/(height*.62),0,1));
      return{x:mix(edge,mix(width*.79,width*.31,sweep),visible),y:clamp(center,85,height-85),size:mix(smallSize,width<=700?34:48,visible),roll:mix(-9,9,sweep)*visible};
    }
    return{x:edge,y:height*(section.id==='contact'?.56:section.id==='work'?.34:.4),size:smallSize,roll:section.id==='contact'?7:-4};
  }
  function draw(){
    frame=0;if(!hero||!sections.length)return;
    let section=sections[0],next=null,amount=0;
    if(!reduced){
      const stops=sections.map((s,i)=>i===0?0:clamp(s.top-height*.28,0,distance));
      let index=0;while(index<stops.length-1&&scrollY>=stops[index+1])index++;
      section=sections[index];
      if(index<sections.length-1){next=sections[index+1];const span=Math.min(height*.52,(stops[index+1]-stops[index])*.48);amount=ease(clamp((scrollY-(stops[index+1]-span))/Math.max(1,span),0,1));}
    }
    const a=pose(section),b=next?pose(next):a;
    const size=mix(a.size,b.size,amount),arc=Math.sin(amount*Math.PI);
    const x=clamp(mix(a.x,b.x,amount),size/2+8,width-size/2-8);
    const y=clamp(mix(a.y,b.y,amount)+arc*(width<=700?12:24),90,height-size/3-8);
    const roll=mix(a.roll,b.roll,amount)+arc*4;
    flight.hidden=false;
    flight.style.transform=`translate3d(${(x-heroSize/2).toFixed(2)}px,${(y-heroSize/3).toFixed(2)}px,0) rotate(${roll.toFixed(2)}deg) scale(${(size/heroSize).toFixed(4)})`;
    flight.dataset.motion=reduced?'reduced':'flying';
    flight.dataset.progress=(reduced?0:clamp(scrollY/distance,0,1)).toFixed(3);
    flight.dataset.section=amount>.5&&next?next.id:section.id;
    flight.dataset.size=size.toFixed(1);
  }
  function schedule(){if(!frame&&!document.hidden)frame=requestAnimationFrame(draw);}
  if(!reduced)addEventListener('scroll',schedule,{passive:true});
  addEventListener('resize',measure,{passive:true});
  document.addEventListener('visibilitychange',()=>{flight.classList.toggle('is-resting',document.hidden);if(!document.hidden)schedule();});
  new ResizeObserver(measure).observe(document.querySelector('main'));
  measure();
}
