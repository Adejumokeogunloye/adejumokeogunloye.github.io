// Restored original frames; identical gaze and scroll mappings to the original site.
export function createPortrait({ canvas, hero, fallback, reduced }) {
  const context = canvas.getContext('2d', { alpha: false });
  const gazeFrames = [1, 5, 10, 15, 30, 34, 39, 44, 50, 56, 62, 68, 74, 80, 86];
  const cache = new Map();
  const memoryBudget = 32 * 1024 * 1024;
  let cacheBytes = 0, targetGaze = 6, gaze = 6, progress = 0;
  let sized = false;
  let visible = true, requested = '', lastKey = '', raf = 0, dirty = true, width = 1280;
  let worker;
  const failed = new Set(), directPending = new Set();
  const diagnostics = { draws: 0, decodedBytes: 0, residentFrames: 0, worker: false };
  canvas.style.opacity = '0';
  function schedule() { if (sized && !raf && visible && !document.hidden) raf = requestAnimationFrame(draw); }
  function releaseOffscreen() {
    for (const [key, entry] of cache) if (key !== lastKey) {
      entry.bitmap.close(); cacheBytes -= entry.bytes; cache.delete(key);
    }
    diagnostics.decodedBytes = cacheBytes; diagnostics.residentFrames = cache.size;
    canvas.dataset.decodedMb = (cacheBytes / 1024 / 1024).toFixed(1);
    canvas.dataset.cachedFrames = String(cache.size);
  }
  function accept({ key, bitmap, frame, width: sourceWidth }) {
    if (!visible || document.hidden) { bitmap.close(); return; }
    if (cache.has(key)) { bitmap.close(); return; }
    const bytes = bitmap.width * bitmap.height * 4;
    cache.set(key, { bitmap, frame, width: sourceWidth, bytes }); cacheBytes += bytes;
    while (cacheBytes > memoryBudget && cache.size > 1) {
      const old = [...cache.keys()].find(k => k !== lastKey && k !== key) || cache.keys().next().value;
      cacheBytes -= cache.get(old).bytes; cache.get(old).bitmap.close(); cache.delete(old);
    }
    diagnostics.decodedBytes = cacheBytes; diagnostics.residentFrames = cache.size;
    schedule();
  }
  try {
    worker = new Worker(new URL('./frame-worker.js', import.meta.url));
    diagnostics.worker = true; canvas.dataset.worker = 'true';
    worker.onmessage = ({ data }) => { if (data.bitmap) accept(data); };
    worker.onerror = () => { worker.terminate(); worker = null; diagnostics.worker = false; canvas.dataset.worker = 'false'; requested = ''; schedule(); };
  } catch { /* Direct decode remains available on browsers without workers. */ }
  async function directLoad(frame, sourceWidth) {
    const key = `${sourceWidth}:${frame}`;
    if (cache.has(key) || directPending.has(key) || failed.has(key) || directPending.size >= 2) return;
    directPending.add(key);
    try {
      const n = String(frame).padStart(3, '0');
      let response = await fetch(`assets/frames-${sourceWidth}/ezgif-frame-${n}.webp`);
      if (!response.ok) response = await fetch(`assets/frames/ezgif-frame-${n}.jpg`);
      if (!response.ok) throw Error('Frame unavailable');
      const blob = await response.blob();
      let bitmap;
      if (typeof createImageBitmap === 'function') bitmap = await createImageBitmap(blob);
      else {
        const image = new Image(), url = URL.createObjectURL(blob);
        try { image.src = url; await image.decode(); bitmap = image; bitmap.close = () => {}; }
        finally { URL.revokeObjectURL(url); }
      }
      accept({ key, frame, width: sourceWidth, bitmap });
    } catch { failed.add(key); }
    finally { directPending.delete(key); requested = ''; schedule(); }
  }
  function prepare(wanted) {
    const ids = [wanted];
    if (reduced) { /* A single sharp front-facing image is sufficient. */ }
    else if (progress > .06) {
      for (let offset = 1; offset <= 4; offset++) {
        if (wanted + offset <= 200) ids.push(wanted + offset);
        if (wanted - offset >= 122) ids.push(wanted - offset);
      }
    } else {
      const index = gazeFrames.indexOf(wanted);
      for (let offset = 1; offset <= 2; offset++) {
        if (index + offset < gazeFrames.length) ids.push(gazeFrames[index + offset]);
        if (index - offset >= 0) ids.push(gazeFrames[index - offset]);
      }
    }
    const capacity = Math.max(1, Math.floor(memoryBudget / (width * width * 9 / 16 * 4)) - 1);
    ids.length = Math.min(ids.length, capacity);
    const signature = `${width}:${ids.join(',')}:${[...cache.keys()].join(',')}`;
    if (signature === requested) return;
    requested = signature;
    if (worker) worker.postMessage({ paused: !visible || document.hidden, resident: [...cache.keys()], priorities: ids.map(frame => ({ frame, width })) });
    else ids.slice(0, 2).forEach(n => directLoad(n, width));
  }
  function draw() {
    raf = 0;
    if (!visible || document.hidden) return;
    gaze += (targetGaze - gaze) * .09;
    if (Math.abs(targetGaze - gaze) < .005) gaze = targetGaze;
    const wanted = !reduced && progress > .06 ? Math.round(122 + progress * 78) : gazeFrames[Math.round(gaze)];
    prepare(wanted);
    let key = `${width}:${wanted}`;
    if (!cache.has(key)) {
      let distance = Infinity;
      for (const [k, image] of cache) {
        const d = Math.abs(image.frame - wanted) + (image.width === width ? 0 : .1);
        if (d < distance) { distance = d; key = k; }
      }
    }
    if (cache.has(key) && (key !== lastKey || dirty)) {
      const entry = cache.get(key), image = entry.bitmap;
      // LRU touch without allocating/sorting an array for each animation frame.
      cache.delete(key); cache.set(key, entry);
      const fit = innerWidth > 1024 ? Math.min(canvas.width / image.width, canvas.height / image.height) : Math.max(canvas.width / image.width, canvas.height / image.height);
      const w = image.width * fit, h = image.height * fit;
      // Restoration and resampling are already baked into the assets.
      // Bilinear display scaling avoids expensive live cubic filtering.
      context.imageSmoothingEnabled = true; context.imageSmoothingQuality = 'low';
      context.fillStyle = '#f2f5f4'; context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
      canvas.style.opacity = '1'; fallback.style.visibility = 'hidden';
      canvas.dataset.frame = String(entry.frame); canvas.dataset.quality = String(entry.width);
      lastKey = key; dirty = false; diagnostics.draws++;
    }
    canvas.dataset.draws = String(diagnostics.draws); canvas.dataset.cachedFrames = String(cache.size);
    canvas.dataset.decodedMb = (cacheBytes / 1024 / 1024).toFixed(1);
    if (Math.abs(targetGaze - gaze) > .005) schedule();
  }
  const observer = new ResizeObserver(() => {
    const r = canvas.getBoundingClientRect();
    sized = true;
    const dpr = Math.min(devicePixelRatio || 1, 2, 2304 / Math.max(r.width, r.height));
    canvas.width = Math.round(r.width * dpr); canvas.height = Math.round(r.height * dpr);
    const needed = innerWidth > 1024 ? Math.min(canvas.width, canvas.height * 16 / 9) : Math.max(canvas.width, canvas.height * 16 / 9);
    width = needed > 1280 ? 1920 : 1280; dirty = true; requested = ''; schedule();
  }); observer.observe(canvas);
  new IntersectionObserver(entries => {
    visible = entries[0].isIntersecting; requested = '';
    if (!visible) { releaseOffscreen(); worker?.postMessage({ paused: true }); }
    else schedule();
  }).observe(hero);
  document.addEventListener('visibilitychange', () => {
    requested = '';
    if (document.hidden) { releaseOffscreen(); worker?.postMessage({ paused: true }); } else schedule();
  });
  document.addEventListener('pointermove', e => {
    if (!reduced && e.pointerType !== 'touch') { targetGaze = Math.max(0, Math.min(14, e.clientX / innerWidth * 14)); schedule(); }
  }, { passive: true });
  hero.addEventListener('pointerleave', () => { targetGaze = 6; schedule(); });
  schedule();
  return { setProgress(value) { progress = value; schedule(); }, diagnostics };
}
