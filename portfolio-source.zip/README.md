# Adejumoke Ogunloye

Website Developer and Designer.

A responsive portfolio with an interactive character, selected project previews, a 3D toolkit, and a consultation request page.

## Edit the website

Website files are in `docs/`. Edit `docs/theme.css` for typography and visual styling, `docs/index.html` for homepage content, and `docs/consultation.html` for the consultation page. Changes pushed to `main` publish through GitHub Actions.

Consultation submissions are handled by a separate Google Apps Script receiver. Visitor records stay in the owner's private Google Sheet and are never committed to this repository.

## Local preview

Run `python -m http.server 8013 --directory docs`, then open http://127.0.0.1:8013/.

The character and profile assets are supplied portfolio media. This repository does not grant reuse rights to those images.
